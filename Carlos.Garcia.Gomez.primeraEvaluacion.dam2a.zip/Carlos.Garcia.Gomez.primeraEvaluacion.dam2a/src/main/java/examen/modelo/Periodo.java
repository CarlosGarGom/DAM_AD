package examen.modelo;

public class Periodo {

	public Periodo() {
		// TODO Auto-generated constructor stub
	}

}
