package examen.modelo;

public class Modelo {

	public Modelo() {
		// TODO Auto-generated constructor stub
		
	}
	

}
