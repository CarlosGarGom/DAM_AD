package examen.modelo;

public class Edad {

	public Edad() {
		// TODO Auto-generated constructor stub
	}

}
