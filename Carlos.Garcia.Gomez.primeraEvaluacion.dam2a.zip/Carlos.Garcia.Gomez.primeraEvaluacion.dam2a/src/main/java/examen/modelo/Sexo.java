package examen.modelo;

public enum Sexo {
	HOMBRE, MUJER
}
