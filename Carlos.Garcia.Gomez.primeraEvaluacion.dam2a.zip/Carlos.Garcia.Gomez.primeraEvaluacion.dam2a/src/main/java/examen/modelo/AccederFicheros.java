package examen.modelo;

public class AccederFicheros {

	public AccederFicheros() {
		// TODO Auto-generated constructor stub
		
	}

}
